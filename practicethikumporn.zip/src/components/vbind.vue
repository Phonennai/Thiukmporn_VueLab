<template>
  <div>
    <h1 v-bind:style="colors">{{ text }}</h1>
    <button @click="changeColor()">change Color</button>

    <br /><br />
    <button v-bind:class="{ green: boolean, blue: !boolean }"></button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      text: "text",
      color: { color: "blue" },
      boolean: true,
    };
  },
  methods: {
    changeColoer() {
      this.colors.color = "red";
    },
  },
};
</script>
<style  scoped>
.green {
  background-color: green;
  width: 100px;
  height: 100px;
}
.blue {
  background-color: blue;
  width: 100px;
  height: 100px;
}
</style>