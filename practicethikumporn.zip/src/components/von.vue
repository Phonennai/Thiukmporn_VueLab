<template>
  <div class="hello3">
    <h1>{{ SayHello(text) }}</h1>
    <h3>{{ itemCode }}</h3>
    <h3>{{ itemCode2 }}</h3>
    <h3>{{ itemCode3 }}</h3>
  </div>
</template>

<script>
export default {
  name: "HelloWorld",
  props: {
    msg: String,
  },
  data() {
    return {
      text: "",
      text2: "",
      itemCode2: "",
      itemCode3: "",
    };
  },
  methods: {
    SayHello(name) {
      return "ผลงานเกี่ยวกับโปรเเกรม";
    },
  },
  created() {
    this.text = "-PROJECT- รายงานจัดจำหน่ายทำนํ้าดื่ม";
    this.text2 = "-PROJECT- ขายเสื้อผ้าผ่านเเชทบอทline";
    this.itemCode2 = this.text;
    this.itemCode3 = this.text2;
  },
  watch: {
    itemCode3() {
      return this.text2;
    },
  },
  comuted: {
    itemCode() {
      return this.text;
    },
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
