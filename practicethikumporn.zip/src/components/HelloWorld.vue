<template>
  <div class="hello">
    <h1>{{ itemCode }}</h1>
    <h1>{{ itemCode2 }}</h1>
    <h1>{{ SayHello(text) }}</h1>
    <h1>{{ msg }}</h1>
    <h1>{{ itemCode3 }}</h1>
  </div>
</template>

<script>
export default {
  name: "HelloWorld",
  props: {
    msg: String,
  },
  data() {
    return {
      text: "",
      text2: "",
      itemCode2: "",
      itemCode3: "",
    };
  },
  methods: {
    SayHello(name) {
      return "นาย ทิฆัมพร ประวัติยากูร  อายุ 22";
    },
  },
  created() {
    this.text = "ศึกษาที่ : มหาวิทยาลัยเกษตรศาสตร์ วิทยาเขตศรีราชา";
    this.text2 = "ทักษะ: เขียนโปรแกรม เล่นเกม";
    this.itemCode2 = this.text;
    this.itemCode3 = this.text2;
  },
  watch: {
    itemCode3() {
      return this.text2;
    },
  },
  comuted: {
    itemCode() {
      return this.text;
    },
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
